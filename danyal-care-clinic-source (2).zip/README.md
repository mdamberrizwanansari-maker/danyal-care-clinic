# Danyal Care Clinic — Android-ready source

A responsive clinic appointment app for:
- Dr. Md Danyal Rizwan Ansari (specialization label: Neurosurgeon; verify credentials before public launch)
- Clinic address: GT Road, Howrah, West Bengal
- Phone/WhatsApp configured to 6299597281 (India country code included for links)

## Important WhatsApp behaviour
The app saves the appointment request in Supabase, then opens WhatsApp with a pre-filled message. The patient must tap **Send**. Automatically sending WhatsApp messages without a user action requires an approved WhatsApp Business Platform integration and server-side credentials; those secrets must never be placed in this app.

## 1. Configure Supabase backend
1. Create a Supabase project.
2. Open SQL Editor and run `supabase/schema.sql`.
3. In Project Settings / API, copy the Project URL and the publishable key (or legacy anon key). Do **not** copy the service_role/secret key into the app.
4. Copy `.env.example` to `.env` and fill in:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_CLINIC_PHONE=916299597281`
   - `VITE_CLINIC_WHATSAPP=916299597281`
5. In Supabase Authentication, create the doctor's admin user manually with a strong password. Do not provide public admin sign-up.
6. Set that user's **app_metadata** to `{"role":"admin"}` through a trusted admin-only route/dashboard mechanism. Do not use user-editable `user_metadata` for authorization. The RLS policy checks app_metadata.
7. Verify the appointment insert and admin-only read/update policies before using real patient data.

## 2. Run web preview
Install Node.js LTS, then in this project folder:
```bash
npm install
npm run dev
```
Open the local URL printed by Vite. On a phone, open the network URL shown by Vite while both devices are on the same network.

## 3. Build Android APK
You need a computer with Android Studio and a compatible Android SDK installed.
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio, wait for Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will show the output path. For future web changes, run:
```bash
npm run build
npx cap sync android
```

## Included screens
- Home / doctor profile (photo-free placeholder illustration)
- Appointment form: patient name, phone, date, preferred time, optional reason
- Tap-to-call clinic
- Doctor admin login
- Appointment list with All / Pending / Accepted / Rejected filters
- Accept/reject status controls, WhatsApp follow-up link, refresh

## Security and launch notes
- The app uses Supabase Auth and Row Level Security for admin data access. Keep the service-role key off the client.
- Patient appointment details are sensitive. Limit access, use a strong unique admin password, enable MFA where possible, and establish a retention policy.
- This is starter source code, not a verified clinical or production deployment. Test thoroughly before handling real patient data.
- Confirm the doctor's qualifications, clinic hours, appointment availability, phone number, and exact map location before publishing.
- This app does not provide medical advice or emergency services.
