import React, { useEffect, useState } from 'react';
import { Activity, CalendarDays, Clock, Phone, ShieldCheck, Stethoscope, CheckCircle2, XCircle, LogOut, ArrowLeft, MessageCircle, Menu, HeartPulse } from 'lucide-react';
import { configured, supabase, clinicPhone, clinicWhatsApp } from './supabase';

const doctor = 'Dr. Md Danyal Rizwan Ansari';
const clinicAddress = 'GT Road, Howrah, West Bengal';

function formatDate(date) {
  if (!date) return '—';
  return new Date(`${date}T00:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}
function waLink(text) {
  return `https://wa.me/${clinicWhatsApp}?text=${encodeURIComponent(text)}`;
}

export default function App() {
  const [page, setPage] = useState('home');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [session, setSession] = useState(null);
  const [appointments, setAppointments] = useState([]);
  const [filter, setFilter] = useState('all');
  const [form, setForm] = useState({ patient_name: '', phone: '', appointment_date: '', appointment_time: '', reason: '' });

  useEffect(() => {
    if (!configured) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (page === 'admin' && session) loadAppointments();
  }, [page, session, filter]);

  function updateForm(e) {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  }

  async function bookAppointment(e) {
    e.preventDefault();
    setNotice('');
    if (!configured) {
      setNotice('App setup abhi complete nahi hai. Supabase configuration ke liye README dekhein.');
      return;
    }
    if (!/^[6-9]\d{9}$/.test(form.phone.trim())) {
      setNotice('Kripya 10-digit Indian mobile number enter karein.');
      return;
    }
    if (form.appointment_date < new Date().toLocaleDateString('en-CA')) {
      setNotice('Past date select nahi kar sakte.');
      return;
    }
    setBusy(true);
    const payload = {
      patient_name: form.patient_name.trim(),
      phone: form.phone.trim(),
      appointment_date: form.appointment_date,
      appointment_time: form.appointment_time,
      reason: form.reason.trim() || null,
      status: 'pending'
    };
    const { error } = await supabase.from('appointments').insert(payload);
    setBusy(false);
    if (error) {
      setNotice('Appointment save nahi hui. Connection/settings check karke dobara try karein.');
      return;
    }
    const message = `New appointment request - Danyal Care Clinic\nName: ${payload.patient_name}\nPhone: ${payload.phone}\nDate: ${payload.appointment_date}\nTime: ${payload.appointment_time}`;
    setNotice('Appointment request submit ho gayi! WhatsApp kholkar clinic ko request bhej dein.');
    setForm({ patient_name: '', phone: '', appointment_date: '', appointment_time: '', reason: '' });
    window.open(waLink(message), '_blank', 'noopener,noreferrer');
  }

  async function login(e) {
    e.preventDefault();
    setNotice('');
    if (!configured) { setNotice('Supabase setup complete nahi hai. README follow karein.'); return; }
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: adminEmail.trim(), password: adminPassword });
    setBusy(false);
    if (error) setNotice('Login nahi hua. Admin email/password verify karein.');
    else { setNotice(''); setPage('admin'); }
  }

  async function loadAppointments() {
    if (!configured || !session) return;
    let query = supabase.from('appointments').select('*').order('appointment_date', { ascending: false }).order('created_at', { ascending: false });
    if (filter !== 'all') query = query.eq('status', filter);
    const { data, error } = await query;
    if (error) setNotice('Appointments load nahi hui. Admin permission / database setup check karein.');
    else setAppointments(data || []);
  }

  async function updateStatus(id, status) {
    const { error } = await supabase.from('appointments').update({ status }).eq('id', id);
    if (error) setNotice('Status update nahi hua. Permission check karein.');
    else { setNotice(`Appointment ${status} ho gayi.`); loadAppointments(); }
  }

  async function logout() {
    await supabase?.auth.signOut();
    setSession(null);
    setAppointments([]);
    setPage('home');
  }

  const today = new Date().toLocaleDateString('en-CA');
  const minDate = today;

  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => { setPage('home'); setNotice(''); }} aria-label="Home">
        <span className="brand-icon"><HeartPulse size={23}/></span>
        <span><strong>Danyal Care</strong><small>CLINIC</small></span>
      </button>
      <button className="admin-shortcut" onClick={() => { setPage(session ? 'admin' : 'login'); setNotice(''); }}>
        <ShieldCheck size={17}/><span>Doctor Login</span>
      </button>
    </header>

    {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice('')} aria-label="Dismiss">×</button></div>}

    {page === 'home' && <>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><span className="live-dot"/> APPOINTMENT & PATIENT CARE</span>
          <h1>Your health.<br/><em>Our priority.</em></h1>
          <p>Book an appointment with {doctor}.</p>
          <div className="hero-actions">
            <button className="btn btn-primary" onClick={() => { setPage('book'); setNotice(''); }}><CalendarDays size={18}/> Book Appointment</button>
            <a className="btn btn-outline" href={`tel:+${clinicPhone}`}><Phone size={17}/> Call Clinic</a>
          </div>
          <div className="doctor-chip"><span className="doctor-avatar"><Stethoscope size={23}/></span><span><b>{doctor}</b><small>Neurosurgeon</small></span><CheckCircle2 size={18} className="verified"/></div>
        </div>
        <div className="hero-art" aria-hidden="true"><div className="art-ring ring-one"/><div className="art-ring ring-two"/><div className="medical-cross">+</div><div className="art-card"><HeartPulse size={55}/><span>CARE WITH<br/>CONFIDENCE</span></div><div className="art-dot dot-one"/><div className="art-dot dot-two"/></div>
      </section>

      <section className="info-strip">
        <div><span className="strip-icon"><CalendarDays/></span><span><b>Easy booking</b><small>Choose a date & time</small></span></div>
        <div><span className="strip-icon"><ShieldCheck/></span><span><b>Private details</b><small>Secure admin access</small></span></div>
        <div><span className="strip-icon"><Phone/></span><span><b>Talk to clinic</b><small>Call in one tap</small></span></div>
      </section>

      <section className="lower-section">
        <div><span className="section-kicker">WELCOME TO DANYAL CARE</span><h2>Care that puts you first.</h2><p>Request an appointment in a few simple steps. The clinic team can review your request and confirm the appointment.</p></div>
        <div className="address-card"><span className="address-icon"><Activity/></span><div><b>Clinic location</b><p>{clinicAddress}</p><a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(clinicAddress)}`} target="_blank" rel="noreferrer">Find directions ↗</a></div></div>
      </section>
      <footer>© {new Date().getFullYear()} Danyal Care Clinic <span>•</span> Patient-first care</footer>
    </>}

    {page === 'book' && <main className="form-page">
      <button className="back-link" onClick={() => { setPage('home'); setNotice(''); }}><ArrowLeft size={17}/> Back to home</button>
      <div className="form-heading"><span className="section-kicker">BOOK A VISIT</span><h1>Request an appointment</h1><p>Fill in your details. Your request will be marked as pending until the clinic reviews it.</p></div>
      <form className="booking-card" onSubmit={bookAppointment}>
        <label>Patient full name<input name="patient_name" value={form.patient_name} onChange={updateForm} required minLength="2" maxLength="100" placeholder="Enter patient name" autoComplete="name"/></label>
        <label>Mobile number<input name="phone" value={form.phone} onChange={updateForm} required inputMode="numeric" pattern="[6-9][0-9]{9}" maxLength="10" placeholder="10-digit mobile number" autoComplete="tel"/></label>
        <div className="field-row"><label>Appointment date<input type="date" name="appointment_date" value={form.appointment_date} onChange={updateForm} required min={minDate}/></label><label>Preferred time<select name="appointment_time" value={form.appointment_time} onChange={updateForm} required><option value="">Choose time</option>{['09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','15:00','15:30','16:00','16:30','17:00','17:30','18:00'].map(t=><option key={t} value={t}>{new Date(`2000-01-01T${t}`).toLocaleTimeString('en-IN',{hour:'numeric',minute:'2-digit'})}</option>)}</select></label></div>
        <label>Reason for visit <span className="optional">(optional)</span><textarea name="reason" value={form.reason} onChange={updateForm} maxLength="500" rows="3" placeholder="Briefly describe the reason for your visit"/></label>
        <div className="privacy-note"><ShieldCheck size={17}/><span>Your information is shared with the clinic to manage this appointment request.</span></div>
        <button className="btn btn-primary full-width" disabled={busy}>{busy ? 'Submitting…' : <><CalendarDays size={18}/> Submit appointment request</>}</button>
        <p className="form-foot">After submitting, WhatsApp will open with your appointment details. You may need to tap Send.</p>
      </form>
    </main>}

    {page === 'login' && <main className="form-page narrow">
      <button className="back-link" onClick={() => { setPage('home'); setNotice(''); }}><ArrowLeft size={17}/> Back to home</button>
      <div className="login-card"><span className="login-icon"><ShieldCheck size={28}/></span><span className="section-kicker">AUTHORIZED ACCESS</span><h1>Doctor admin login</h1><p>Sign in to securely manage appointment requests.</p>
        <form onSubmit={login}><label>Admin email<input type="email" value={adminEmail} onChange={e=>setAdminEmail(e.target.value)} required autoComplete="username" placeholder="admin@example.com"/></label><label>Password<input type="password" value={adminPassword} onChange={e=>setAdminPassword(e.target.value)} required autoComplete="current-password" placeholder="Enter password"/></label><button className="btn btn-primary full-width" disabled={busy}>{busy ? 'Signing in…' : <><ShieldCheck size={18}/> Secure login</>}</button></form>
        <small className="security-caption">Admin accounts must be created by the project owner in Supabase. There is no public admin sign-up.</small>
      </div>
    </main>}

    {page === 'admin' && <main className="admin-page">
      <div className="admin-head"><div><span className="section-kicker">CLINIC MANAGEMENT</span><h1>Appointments</h1><p>Review and manage patient appointment requests.</p></div><button className="btn btn-outline logout-btn" onClick={logout}><LogOut size={17}/> Logout</button></div>
      {!session ? <div className="empty-state"><ShieldCheck size={30}/><h3>Admin login required</h3><button className="btn btn-primary" onClick={()=>setPage('login')}>Go to login</button></div> :
      <>
        <div className="admin-stats"><div><small>Total shown</small><b>{appointments.length}</b></div><div><small>Pending shown</small><b>{appointments.filter(a=>a.status==='pending').length}</b></div><div><small>Confirmed shown</small><b>{appointments.filter(a=>a.status==='accepted').length}</b></div></div>
        <div className="filters">{[['all','All'],['pending','Pending'],['accepted','Accepted'],['rejected','Rejected']].map(([key,label])=><button key={key} className={filter===key?'active':''} onClick={()=>setFilter(key)}>{label}</button>)}</div>
        {appointments.length===0 ? <div className="empty-state"><CalendarDays size={32}/><h3>No appointments found</h3><p>New appointment requests will appear here.</p></div> :
          <div className="appointment-list">{appointments.map(a=><article className="appointment-card" key={a.id}>
            <div className="appointment-card-top"><div className="patient-badge">{a.patient_name?.slice(0,1)?.toUpperCase() || 'P'}</div><div className="patient-title"><h3>{a.patient_name}</h3><a href={`tel:${a.phone}`}><Phone size={14}/> {a.phone}</a></div><span className={`status status-${a.status}`}>{a.status}</span></div>
            <div className="appointment-meta"><span><CalendarDays size={16}/>{formatDate(a.appointment_date)}</span><span><Clock size={16}/>{a.appointment_time}</span></div>
            {a.reason && <p className="reason"><b>Reason:</b> {a.reason}</p>}
            <div className="card-actions"><a className="mini-btn whatsapp" href={waLink(`Hello ${a.patient_name}, this is Danyal Care Clinic regarding your appointment on ${formatDate(a.appointment_date)} at ${a.appointment_time}.`)} target="_blank" rel="noreferrer"><MessageCircle size={15}/> WhatsApp</a>
              {a.status!=='accepted' && <button className="mini-btn accept" onClick={()=>updateStatus(a.id,'accepted')}><CheckCircle2 size={15}/> Accept</button>}
              {a.status!=='rejected' && <button className="mini-btn reject" onClick={()=>updateStatus(a.id,'rejected')}><XCircle size={15}/> Reject</button>}
            </div>
          </article>)}</div>}
        <button className="refresh-btn" onClick={loadAppointments}>↻ Refresh appointments</button>
      </>}
    </main>}

    <a className="floating-call" href={`tel:+${clinicPhone}`} aria-label="Call clinic"><Phone size={20}/></a>
  </div>;
}
