import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'in.danyalcare.clinic',
  appName: 'Danyal Care Clinic',
  webDir: 'dist',
  server: { androidScheme: 'https' }
};
export default config;
