# Danyal Care Clinic — Web App & Admin Panel

A responsive clinic appointment website for patients and a private doctor admin panel. This version is web-only.

## Features
- Patient appointment request form with name, Indian mobile number, date, time and optional reason
- Tap-to-call clinic and WhatsApp follow-up links
- Doctor login through Supabase Auth (no public admin sign-up)
- Admin appointment list with All / Pending / Accepted / Rejected filters
- Search by patient name or mobile number and filter by appointment date
- Accept/reject controls and refresh with loading feedback
- Supabase Row Level Security policies for patient appointment data

## Setup
1. Install Node.js LTS on a computer.
2. In this project folder run `npm install`.
3. Copy `.env.example` to `.env` and enter your Supabase project URL and publishable/anon key. Verify the clinic phone and WhatsApp numbers before launch.
4. In Supabase Dashboard → SQL Editor, run the full `supabase/schema.sql` file.
5. In Supabase Authentication, create the doctor's admin account manually. Set `app_metadata` to `{"role":"admin"}` using a trusted admin-only method. Do not use user-editable `user_metadata` for authorization.
6. Start the site with `npm run dev`. Create a production build with `npm run build`; preview it with `npm run preview`.

## Environment variables
- `VITE_SUPABASE_URL` — Supabase project URL
- `VITE_SUPABASE_ANON_KEY` — Supabase publishable/anon key only
- `VITE_CLINIC_PHONE` — clinic phone with country code, digits only
- `VITE_CLINIC_WHATSAPP` — WhatsApp number with country code, digits only

## Important security notes
- Never put a Supabase `service_role` or secret key in `.env` or frontend code.
- Keep admin account creation restricted; use a strong unique password and enable MFA where possible.
- The database allows public appointment INSERT only; appointment SELECT/UPDATE are restricted to users whose JWT `app_metadata.role` is `admin`. Test this with a non-admin account before using real patient data.
- Public appointment forms can attract spam. Before a public launch, add CAPTCHA/rate limiting through a trusted backend or edge function.
- Patient details are sensitive. Limit access and define a retention policy.

## WhatsApp behaviour
The site saves the appointment request in Supabase and opens WhatsApp with a pre-filled message. The patient must tap **Send**. Automatic sending requires an approved WhatsApp Business Platform integration and server-side credentials.

## Before publishing
Verify the doctor's name, qualifications/specialization, clinic hours, exact address, phone and WhatsApp numbers. The current starter data lists Dr. Md Danyal Rizwan Ansari, “Neurosurgeon”, GT Road, Howrah, West Bengal and phone/WhatsApp 6299597281; confirm every detail with the clinic. This starter project is not a verified production deployment and does not provide medical advice or emergency services.
